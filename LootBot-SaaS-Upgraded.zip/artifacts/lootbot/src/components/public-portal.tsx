import { useState, type FormEvent } from "react";
import { Link } from "wouter";
import {
  ArrowUpLeft,
  BarChart3,
  BookOpen,
  Check,
  ChevronLeft,
  ClipboardCheck,
  Compass,
  GraduationCap,
  KeyRound,
  Layers,
  MessageCircle,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Store,
  Target,
  Users,
  Zap,
} from "lucide-react";
import { BrandMark } from "./brand-mark";
import { teacherApi } from "../lib/teacher-api";
import "./public-portal.css";

type Props = { locale: "ar" | "en"; toggleLocale: () => void };

export function PublicLanding({ locale, toggleLocale }: Props) {
  const ar = locale === "ar";
  const [activeTrack, setActiveTrack] = useState<"education" | "commerce">(
    "education",
  );

  const pillars = [
    {
      icon: Sparkles,
      badge: ar ? "تفاعلي 3D" : "3D Interactive",
      title: ar ? "مختبر الكيمياء ثلاثي الأبعاد" : "3D Chemistry Lab",
      text: ar
        ? "تجارب تفاعلية بالعربية مع التحقق من حفظ الذرات واستئناف المحاكاة."
        : "Interactive Arabic 3D simulations with atom conservation checks.",
    },
    {
      icon: Target,
      badge: ar ? "تدريب وتقييم" : "Practice & Exams",
      title: ar ? "مركز القدرات ومحرر الاختبارات" : "Quant Center & Exam Studio",
      text: ar
        ? "تدريب كمي بمسودة تفاعلية، وفيديوهات شرح، وتصدير أوراق عمل A4 للمعلم."
        : "Quantitative drills with interactive scratchpad, video lessons, and A4 exams.",
    },
    {
      icon: MessageCircle,
      badge: ar ? "أتمتة المتاجر" : "Store Automation",
      title: ar ? "استوديو بوت Telegram والمتجر" : "Telegram Bot & Store Studio",
      text: ar
        ? "ربط الكتالوج ببوت تيليجرام، وتخصيص شاشات المحادثة، وإدارة الطلبات."
        : "Sync product catalogs with Telegram bots, customize screens, and track orders.",
    },
    {
      icon: ShieldCheck,
      badge: ar ? "عزل وحماية" : "Isolated & Secure",
      title: ar ? "مساحات مستقلة وآمنة" : "Private Isolated Workspaces",
      text: ar
        ? "جلسات معزولة لكل طالب ومعلم وتاجر مع تشفير رموز البوت وبصمات الدخول."
        : "Separate sessions for students, teachers, and merchants with encrypted tokens.",
    },
  ];

  const spaces = [
    {
      icon: GraduationCap,
      badge: ar ? "مسار الطالب • دخول فوري" : "Student Track • Instant Code",
      title: ar ? "غرفة الطالب" : "Student room",
      text: ar
        ? "ادخل برمزك الشخصي دون بريد أو كلمة مرور، وافتح أنشطتك ومختبر الكيمياء وخطة تعلمك."
        : "Use your personal code without email or password to open activities, the 3D lab, and learning plans.",
      features: ar
        ? [
            "دخول مباشر برمز الطالب الشخصي",
            "مختبر كيمياء تفاعلي 3D وأنشطة تفاعلية",
            "مركز تدريب القدرات الكمي مع مسودة حل",
          ]
        : [
            "Direct access via personal student code",
            "Interactive 3D Chemistry Lab & lessons",
            "Quantitative aptitude practice & scratchpad",
          ],
      href: "/student-entry",
      cta: ar ? "التسجيل كطالب" : "Student access",
    },
    {
      icon: BookOpen,
      badge: ar ? "مسار المعلم • إدارة وتصميم" : "Teacher Track • Studio & Labs",
      title: ar ? "مساحة المعلم" : "Teacher workspace",
      text: ar
        ? "نظّم فصولك، صمّم اختباراتك التفاعلية وأوراق A4، وتابع تقدم الطلاب من إجاباتهم الفعلية."
        : "Organize classes, design interactive exams and A4 sheets, and track real student progress.",
      features: ar
        ? [
            "محرر اختبارات متقدم مع دعم المسح الضوئي OCR",
            "إسناد تجارب الكيمياء 3D والتمارين للفصول",
            "تحليلات دقيقة للدرجات وتصدير تقارير الحضور",
          ]
        : [
            "Advanced exam editor with OCR support",
            "Assign 3D chemistry labs & class activities",
            "Granular grade analytics & roster exports",
          ],
      href: "/login",
      cta: ar ? "دخول المعلم" : "Teacher sign in",
    },
    {
      icon: Store,
      badge: ar ? "مسار التجارة • متجر وبوت" : "Commerce Track • Bot & Store",
      title: ar ? "إدارة المتجر وبوت Telegram" : "Store & Telegram Bot",
      text: ar
        ? "أنشئ متجرك الرقمي، واربط بوت تيليجرام التفاعلي، وأدر المنتجات والعملاء والتحليلات في مكان واحد."
        : "Launch your digital store, connect an interactive Telegram bot, and manage products and analytics.",
      features: ar
        ? [
            "استوديو تصميم شاشات وأزرار بوت Telegram",
            "إدارة المنتجات والتصنيفات وحالات الطلبات",
            "محرر قواعد العملاء، الكوبونات، وتحليلات النمو",
          ]
        : [
            "Visual Telegram bot screen & button studio",
            "Product catalog, categories, and order workflow",
            "Customer segmentation rules, coupons & analytics",
          ],
      href: "/register",
      cta: ar ? "إنشاء حساب متجر" : "Create store account",
    },
  ];

  const isEdu = activeTrack === "education";

  return (
    <main className="portal" dir={ar ? "rtl" : "ltr"}>
      <header className="portal-header">
        <Link className="portal-brand" href="/">
          <BrandMark />
          <span>
            LootBot
            <small>
              {ar
                ? "منصة التعليم التفاعلي 3D والمتاجر الذكية"
                : "3D Education & Smart Commerce Platform"}
            </small>
          </span>
        </Link>
        <nav aria-label={ar ? "التنقل الرئيسي" : "Main navigation"}>
          <a className="portal-nav-link" href="#pillars">
            {ar ? "مميزات المنصة" : "Platform features"}
          </a>
          <a className="portal-nav-link" href="#spaces">
            {ar ? "المسارات" : "Workspaces"}
          </a>
          <button className="portal-locale" onClick={toggleLocale}>
            {ar ? "EN" : "العربية"}
          </button>
          <Link className="portal-nav-link" href="/login">
            {ar ? "تسجيل الدخول" : "Sign in"}
          </Link>
          <Link className="portal-button small" href="/student-entry">
            {ar ? "التسجيل كطالب" : "Student access"}
            <KeyRound size={16} />
          </Link>
        </nav>
      </header>

      <section className="portal-hero">
        <div className="portal-intro">
          <div className="portal-eyebrow">
            <span />
            {ar
              ? "منظومة سحابية موحدة للتعليم التفاعلي والتجارة الرقمية"
              : "Unified cloud platform for interactive learning & digital commerce"}
          </div>
          <h1>
            {ar ? (
              <>
                خطوتك القادمة،
                <br />
                <em>تبدأ من مساحتك.</em>
              </>
            ) : (
              <>
                Your next chapter
                <br />
                <em>starts in your space.</em>
              </>
            )}
          </h1>
          <p>
            {ar
              ? "تجمع LootBot بين مسارين متكاملين: بيئة تعليمية تفاعلية تضم مختبر كيمياء ثلاثي الأبعاد ومركز قدرات وأدوات للمعلم، ومنظومة تجارة إلكترونية متكاملة مع استوديو بوت تيليجرام."
              : "LootBot unites two complete ecosystems: an interactive education suite with a 3D chemistry lab and teacher studio, and a full e-commerce platform powered by a Telegram bot studio."}
          </p>

          <div className="portal-track-pills" role="tablist">
            <button
              type="button"
              role="tab"
              aria-selected={isEdu}
              className={`portal-track-pill ${isEdu ? "active" : ""}`}
              onClick={() => setActiveTrack("education")}
            >
              <GraduationCap size={16} />
              {ar ? "معاينة مسار التعليم ومختبر 3D" : "Preview Education & 3D Lab"}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={!isEdu}
              className={`portal-track-pill ${!isEdu ? "active" : ""}`}
              onClick={() => setActiveTrack("commerce")}
            >
              <Store size={16} />
              {ar ? "معاينة مسار المتجر وبوت Telegram" : "Preview Store & Telegram Bot"}
            </button>
          </div>

          <div className="portal-cta">
            <Link href="/student-entry" className="portal-button">
              {ar ? "ابدأ كطالب بالرمز" : "Enter with student code"}
              <ArrowUpLeft size={19} />
            </Link>
            <Link href="/login" className="portal-button secondary">
              {ar ? "دخول المعلم / التاجر" : "Teacher / Merchant sign in"}
            </Link>
          </div>
          <div className="portal-trust">
            <ShieldCheck size={18} />
            {ar
              ? "رمز الطالب شخصي ومشفر • بيانات كل معلم ومتجر معزولة بالكامل في مساحتها الخاصة."
              : "Personal encrypted student codes • Every teacher and merchant workspace is strictly isolated."}
          </div>
        </div>

        <div
          className="portal-scene"
          aria-label={
            ar ? "استكشف مساحات المنصة" : "Explore platform workspaces"
          }
        >
          <div className="portal-orbit" aria-hidden="true" />
          <div className="portal-glass-window">
            <div className="portal-window-top">
              <span className="portal-window-dots">
                <i />
                <i />
                <i />
              </span>
              <div className="portal-window-tabs">
                <button
                  type="button"
                  className={isEdu ? "active" : ""}
                  onClick={() => setActiveTrack("education")}
                >
                  {ar ? "التعليم ومختبر 3D" : "Education & 3D"}
                </button>
                <button
                  type="button"
                  className={!isEdu ? "active" : ""}
                  onClick={() => setActiveTrack("commerce")}
                >
                  {ar ? "المتجر وبوت Telegram" : "Store & Telegram"}
                </button>
              </div>
              <Layers size={18} />
            </div>

            {isEdu ? (
              <>
                <div className="portal-window-heading">
                  <div className="portal-floating-icon">
                    <GraduationCap size={39} />
                  </div>
                  <div>
                    <small>
                      {ar
                        ? "LOOTBOT للتعليم • مختبر 3D والقدرات"
                        : "LOOTBOT EDUCATION • 3D LAB & QUANT"}
                    </small>
                    <h2>
                      {ar
                        ? "معرفة أعمق. تجربة تفاعلية."
                        : "Learn deeper. Experience interactively."}
                    </h2>
                  </div>
                </div>
                <div className="portal-path">
                  <span>
                    <Compass size={17} />
                    {ar ? "اختر مساحتك" : "Choose space"}
                  </span>
                  <ChevronLeft size={15} />
                  <span>
                    <KeyRound size={17} />
                    {ar ? "ادخل برمزك" : "Enter code"}
                  </span>
                  <ChevronLeft size={15} />
                  <span>
                    <Check size={17} />
                    {ar ? "تفاعل وتعلّم" : "Interact & learn"}
                  </span>
                </div>
                <div className="portal-scene-grid">
                  <Link href="/student-entry">
                    <Sparkles />
                    <strong>
                      {ar ? "مختبر الكيمياء 3D" : "3D Chemistry Lab"}
                    </strong>
                    <small>
                      {ar
                        ? "محاكاة تفاعلية ثلاثية الأبعاد وحفظ الذرات"
                        : "3D interactive simulations & atom balance"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/student-entry">
                    <Target />
                    <strong>{ar ? "مركز القدرات" : "Aptitude center"}</strong>
                    <small>
                      {ar
                        ? "تدريب كمي بمسودة ذكية وفيديوهات تأسيس"
                        : "Quantitative drills, scratchpad & videos"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/login">
                    <ClipboardCheck />
                    <strong>
                      {ar ? "استوديو الاختبارات" : "Teacher Exam Studio"}
                    </strong>
                    <small>
                      {ar
                        ? "تصميم اختبارات، مسح ضوئي OCR، وطباعة A4"
                        : "Exam builder, OCR scanning & A4 print"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/student-entry">
                    <BookOpen />
                    <strong>
                      {ar ? "الأنشطة والفصول" : "Classes & Activities"}
                    </strong>
                    <small>
                      {ar
                        ? "خطط تعلم فردية ومتابعة فورية للدرجات"
                        : "Personal study plans & live grade tracking"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                </div>
                <div className="portal-scene-note">
                  <ShieldCheck size={18} />
                  <p>
                    {ar
                      ? "مساحتك التعليمية خاصة بك. افتح تجارب الكيمياء 3D وأنشطتك وتابع تقدمك بعد الدخول."
                      : "Your learning space is private. Open 3D chemistry labs and track your progress."}
                  </p>
                </div>
              </>
            ) : (
              <>
                <div className="portal-window-heading">
                  <div className="portal-floating-icon commerce">
                    <Store size={39} />
                  </div>
                  <div>
                    <small>
                      {ar
                        ? "LOOTBOT للمتاجر • أتمتة تيليجرام"
                        : "LOOTBOT COMMERCE • TELEGRAM STUDIO"}
                    </small>
                    <h2>
                      {ar
                        ? "متجرك وبوتك. في لوحة واحدة."
                        : "Your store & bot. One unified studio."}
                    </h2>
                  </div>
                </div>
                <div className="portal-path">
                  <span>
                    <ShoppingBag size={17} />
                    {ar ? "أضف منتجاتك" : "Add products"}
                  </span>
                  <ChevronLeft size={15} />
                  <span>
                    <MessageCircle size={17} />
                    {ar ? "اربط بوت Telegram" : "Connect Bot"}
                  </span>
                  <ChevronLeft size={15} />
                  <span>
                    <Zap size={17} />
                    {ar ? "استقبل الطلبات" : "Receive orders"}
                  </span>
                </div>
                <div className="portal-scene-grid">
                  <Link href="/register">
                    <MessageCircle />
                    <strong>
                      {ar ? "استوديو بوت Telegram" : "Telegram Bot Studio"}
                    </strong>
                    <small>
                      {ar
                        ? "تخصيص شاشات الترحيب والأزرار التفاعلية"
                        : "Customize welcome screens & bot buttons"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/register">
                    <ShoppingBag />
                    <strong>
                      {ar ? "الكتالوج والطلبات" : "Catalog & Orders"}
                    </strong>
                    <small>
                      {ar
                        ? "إدارة المخزون، التصنيفات، وتأكيد المدفوعات"
                        : "Manage inventory, categories & payments"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/register">
                    <Users />
                    <strong>
                      {ar ? "قواعد العملاء والولاء" : "Customer Rules & Loyalty"}
                    </strong>
                    <small>
                      {ar
                        ? "شرائح العملاء، الكوبونات، والعروض المخصصة"
                        : "Customer segments, coupons & automation"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                  <Link href="/register">
                    <BarChart3 />
                    <strong>
                      {ar ? "تحليلات النمو والفرق" : "Growth & Team Analytics"}
                    </strong>
                    <small>
                      {ar
                        ? "مؤشرات الإيرادات وإدارة صلاحيات الفريق"
                        : "Revenue metrics & team role permissions"}
                    </small>
                    <ArrowUpLeft size={17} />
                  </Link>
                </div>
                <div className="portal-scene-note">
                  <ShieldCheck size={18} />
                  <p>
                    {ar
                      ? "يُخزّن رمز البوت مشفّراً بالكامل، مع مزامنة فورية للكتالوج والطلبات عبر تيليجرام."
                      : "Bot tokens are encrypted at rest with real-time Telegram catalog synchronization."}
                  </p>
                </div>
              </>
            )}
          </div>

          <div className="portal-floating-label">
            {isEdu ? <KeyRound size={20} /> : <MessageCircle size={20} />}
            <div>
              <b>
                {isEdu
                  ? ar
                    ? "للطالب: رمز واحد فقط"
                    : "Students: just one code"
                  : ar
                    ? "للتاجر: ربط فوري مع BotFather"
                    : "Merchants: instant BotFather sync"}
              </b>
              <small>
                {isEdu
                  ? ar
                    ? "يجهّزه المعلم أو المدرسة دون تعقيد"
                    : "Provided by your teacher or school"
                  : ar
                    ? "كتالوج تفاعلي متكامل داخل تيليجرام"
                    : "Interactive catalog right inside Telegram"}
              </small>
            </div>
          </div>
        </div>
      </section>

      <section className="portal-pillars" id="pillars">
        <div className="portal-pillars-grid">
          {pillars.map((p) => (
            <div className="portal-pillar-card" key={p.title}>
              <div className="portal-pillar-top">
                <div className="portal-pillar-icon">
                  <p.icon size={20} />
                </div>
                <span className="portal-pillar-badge">{p.badge}</span>
              </div>
              <h3>{p.title}</h3>
              <p>{p.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="portal-spaces" id="spaces">
        <div className="portal-section-title">
          <span>
            {ar
              ? "مسارات واضحة لكل مستخدم"
              : "Clear workspaces for every role"}
          </span>
          <h2>
            {ar
              ? "اختر المسار المناسب لك وابدأ فوراً."
              : "Choose the workspace built for your role."}
          </h2>
        </div>
        <div className="portal-space-grid">
          {spaces.map((s) => (
            <article className="portal-space-card" key={s.href}>
              <div className="portal-card-header">
                <div className="portal-card-icon">
                  <s.icon size={27} />
                </div>
                <span className="portal-card-badge">{s.badge}</span>
              </div>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
              <ul className="portal-card-features">
                {s.features.map((feat) => (
                  <li key={feat}>
                    <Check size={15} />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
              <Link href={s.href}>
                {s.cta}
                <ArrowUpLeft size={18} />
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="portal-bottom">
        <div>
          <span>
            {ar
              ? "بداية بسيطة. مساحة خاصة."
              : "A simple start. Your own space."}
          </span>
          <h2>{ar ? "وصلك رمز من معلمك؟" : "Got a code from your teacher?"}</h2>
          <p>
            {ar
              ? "اضغط التسجيل كطالب والصق الرمز الشخصي لفتح أنشطتك ومختبر الكيمياء 3D ومركز القدرات دون بريد أو كلمة مرور."
              : "Choose student access and paste your personal code to open activities, the 3D chemistry lab, and aptitude drills."}
          </p>
        </div>
        <Link className="portal-button" href="/student-entry">
          {ar ? "افتح غرفة الطالب" : "Open the student room"}
          <ArrowUpLeft size={18} />
        </Link>
      </section>

      <footer className="portal-footer">
        <Link className="portal-brand" href="/">
          <BrandMark small />
          <b>LootBot</b>
        </Link>
        <span>
          {ar
            ? "منصة LootBot-SaaS — التعليم التفاعلي 3D وإدارة المتاجر الذكية في بنية واحدة."
            : "LootBot-SaaS — 3D interactive education and smart commerce in one platform."}
        </span>
        <div className="portal-footer-links">
          <Link href="/student-entry">
            {ar ? "دخول الطالب" : "Student access"}
          </Link>
          <Link href="/register">{ar ? "إنشاء متجر" : "Create store"}</Link>
          <Link href="/login">{ar ? "تسجيل الدخول" : "Sign in"}</Link>
        </div>
      </footer>
    </main>
  );
}

export function StudentCodeEntry({ locale, toggleLocale }: Props) {
  const ar = locale === "ar",
    [code, setCode] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await teacherApi("/auth/student-code", "POST", { code });
      window.location.assign("/student");
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : ar
            ? "تعذر الدخول. حاول مجددًا."
            : "Unable to sign in. Please try again.",
      );
      setBusy(false);
    }
  }
  return (
    <main className="portal portal-entry" dir={ar ? "rtl" : "ltr"}>
      <header className="portal-header">
        <Link className="portal-brand" href="/">
          <BrandMark />
          <b>LootBot</b>
        </Link>
        <button className="portal-locale" onClick={toggleLocale}>
          {ar ? "EN" : "العربية"}
        </button>
      </header>
      <div className="portal-entry-grid">
        <section className="portal-entry-story">
          <span className="portal-eyebrow">
            {ar ? "غرفة الطالب" : "STUDENT ROOM"}
          </span>
          <h1>
            {ar ? (
              <>
                رحلتك تبدأ
                <br />
                <em>برمز واحد.</em>
              </>
            ) : (
              <>
                One code.
                <br />
                <em>Your next chapter.</em>
              </>
            )}
          </h1>
          <p>
            {ar
              ? "معلمك يجهّز حسابك وفصلك. أنت تدخل الرمز، وتكمل التعلم من حيث توقفت."
              : "Your teacher prepares your account and class. Enter your code and continue learning."}
          </p>
          <div className="portal-entry-benefits">
            <p>
              <Check size={18} />
              {ar ? "دون بريد إلكتروني أو كلمة مرور" : "No email or password"}
            </p>
            <p>
              <Check size={18} />
              {ar
                ? "أنشطتك ومختبر الكيمياء 3D في مكان واحد"
                : "Activities and 3D Chemistry Lab in one place"}
            </p>
            <p>
              <ShieldCheck size={18} />
              {ar
                ? "رمز شخصي، ونتائج خاصة بك"
                : "Personal code, private results"}
            </p>
          </div>
        </section>
        <section className="portal-entry-card">
          <div className="portal-card-icon">
            <KeyRound size={29} />
          </div>
          <h2>{ar ? "التسجيل كطالب" : "Student access"}</h2>
          <p>
            {ar
              ? "لأول دخول أو للعودة إلى حسابك: الصق رمز الدخول الشخصي الذي أعطاك معلمك أو مدرستك."
              : "For your first visit or to return: paste the personal access code from your teacher or school."}
          </p>
          <form onSubmit={submit}>
            <label htmlFor="personal-student-code">
              {ar ? "رمز الدخول الشخصي" : "Personal access code"}
            </label>
            <input
              id="personal-student-code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
              maxLength={100}
              dir="ltr"
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX"
            />
            <span className="portal-input-hint">
              {ar
                ? "هذا الرمز خاص بك؛ رمز انضمام الفصل العام لا يصلح للدخول."
                : "Use your personal code, not a shared classroom join code."}
            </span>
            {error && (
              <p className="portal-error" role="alert">
                {error}
              </p>
            )}
            <button className="portal-button" disabled={busy || !code.trim()}>
              {busy
                ? ar
                  ? "جار فتح غرفتك…"
                  : "Opening your room…"
                : ar
                  ? "ادخل إلى غرفتي"
                  : "Open my room"}
              <ArrowUpLeft size={18} />
            </button>
          </form>
          <div className="portal-entry-help">
            <p>
              {ar
                ? "ما عندك رمز؟ اطلب من معلمك تجهيز حسابك أو تجديد رمزك."
                : "No code? Ask your teacher to prepare your account or renew your code."}
            </p>
            <Link href="/login">
              {ar
                ? "دخول المعلم أو الحساب العادي"
                : "Teacher or regular account sign in"}
            </Link>
            <Link href="/">{ar ? "العودة إلى الرئيسية" : "Back to home"}</Link>
          </div>
        </section>
      </div>
    </main>
  );
}

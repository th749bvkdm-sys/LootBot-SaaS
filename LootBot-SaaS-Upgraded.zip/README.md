# LootBot-SaaS

منصة سحابية ثنائية اللغة (العربية والإنجليزية) مبنية بهيكلة **Monorepo** تجمع بين مسارين متكاملين في بنية واحدة:
1. **منظومة التعليم التفاعلي ومختبر الكيمياء ثلاثي الأبعاد (3D Education & Quant Suite):** غرفة الطالب بالدخول الشخصي السريع، مساحة المعلم وتصميم الاختبارات (مع دعم OCR وطباعة A4)، مختبر الكيمياء التفاعلي ثلاثي الأبعاد، ومركز تدريب القدرات الكمي المزود بمسودة ذكية وفيديوهات تأسيس.
2. **منظومة التجارة الإلكترونية واستوديو بوت تيليجرام (Storefront & Telegram Bot Studio):** إدارة الكتالوج والتصنيفات والطلبات، استوديو مرئي لتخصيص شاشات وأزرار بوت تيليجرام، محرر قواعد وشرائح العملاء والكوبونات، وتحليلات النمو وإدارة الفرق.

## المسارات الرئيسية في الواجهة

| المسار | المستخدم المستهدف | أبرز الإمكانات |
| :--- | :--- | :--- |
| `/` | الزوار | بوابة موحدة بتصميم Glassmorphism مع مبدّل معاينة تفاعلي بين مسار التعليم 3D ومسار المتجر وبوت Telegram |
| `/student-entry` و `/student` | الطالب | دخول فوري بالرمز الشخصي، أنشطة الفصل، مختبر الكيمياء 3D، ومركز القدرات الكمي |
| `/login` و `/teacher` | المعلم | إدارة الفصول والطلاب، محرر الاختبارات والتمارين التفاعلية، المسح الضوئي OCR، وتقارير الدرجات |
| `/register` و `/dashboard/*` | التاجر | إدارة المتجر والمنتجات والطلبات، استوديو بوت Telegram، قواعد العملاء، والتحليلات |
| `/admin` | المشرف العام (Super Admin) | إدارة الخطط والاشتراكات والرقابة الشاملة على المنصة |

## التشغيل المحلي (Local Development)

المتطلبات: `Node.js 24`، و`pnpm` (عبر `Corepack`)، وقاعدة بيانات `PostgreSQL 16` (أو Docker Desktop).

1. تفعيل Corepack وتثبيت الحزم:
   ```bash
   corepack enable
   pnpm install
   ```
2. نسخ ملف البيئة `.env.example` إلى `.env` وتوليد قيمة عشوائية آمنة لـ `SESSION_SECRET` (بطول 32 حرفاً على الأقل):
   ```bash
   node -e "console.log(require('node:crypto').randomBytes(48).toString('base64url'))"
   ```
3. تشغيل قاعدة البيانات محلياً وتهيئة الجداول:
   ```bash
   docker compose up -d db
   pnpm db:push
   ```
4. تشغيل الخادم والواجهة معاً:
   ```bash
   pnpm dev
   ```
   تعمل الواجهة الأمامية على `http://localhost:5173` والخادم الخلفي على المنفذ `5000`.

لترقية حساب مسجل إلى مشرف عام (`SUPERADMIN`) في قاعدة البيانات المحلية:
```powershell
docker compose exec db psql -U lootbot -d lootbot -c "UPDATE users SET role = 'SUPERADMIN' WHERE email = 'your@email.com';"
```

## النشر السحابي على Render

ملف `render.yaml` مهيأ للنشر المباشر على خدمة ويب Render مع قاعدة بيانات Neon PostgreSQL:
- يقوم أمر البناء بتفعيل `Corepack` وتثبيت الحزم، ثم تشغيل فحص الأنواع الموحد (`pnpm run typecheck`)، يليه بناء `@workspace/api-server` و`@workspace/lootbot` وتطبيق ترحيلات قاعدة البيانات (`db:migrate`).
- يقدم الخادم في بيئة الإنتاج كلاً من الواجهة المبنية ومسارات `/api/*` من عملية واحدة مع فحص الحالة عبر `/api/healthz`.

## خريطة المستودع (Workspace Map)

- `artifacts/lootbot`: تطبيق الواجهة الأمامية (React 19, Vite 7, Tailwind CSS 4, Three.js).
- `artifacts/api-server`: خادم الواجهة الخلفية (Express 5, Drizzle ORM, Telegram Bot Runtime).
- `lib/db`: مخططات قاعدة البيانات وترحيلات PostgreSQL.
- `lib/api-spec` و `lib/api-zod` و `lib/api-client-react`: مواصفات OpenAPI وعقود التحقق ومولد عميل React Query.

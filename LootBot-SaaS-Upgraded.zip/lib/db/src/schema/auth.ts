import { createInsertSchema } from "drizzle-zod";
import { boolean, check, integer, pgTable, text, timestamp, type AnyPgColumn } from "drizzle-orm/pg-core";
import { sql } from 'drizzle-orm';
import { z } from "zod/v4";
import { educationStudentAccessTable } from './education';

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("OWNER"),
  // Legacy users stay merchants; registration explicitly starts without a choice.
  accountType: text("account_type").default("merchant"),
  failedLoginAttempts: integer("failed_login_attempts").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  isDeleted: boolean("is_deleted").notNull().default(false),
  suspended: boolean("suspended").notNull().default(false),
  studentCodeManaged: boolean("student_code_managed").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => [check('users_account_type_check', sql`${t.accountType} IS NULL OR ${t.accountType} IN ('merchant','teacher','student')`)]);

export const sessionsTable = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  csrfHash: text("csrf_hash").notNull(),
  studentAccessId: text("student_access_id").references((): AnyPgColumn => educationStudentAccessTable.id),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertSessionSchema = createInsertSchema(sessionsTable).omit({
  id: true,
  createdAt: true,
  lastSeenAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
export type Session = typeof sessionsTable.$inferSelect;

import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: Math.max(1,Math.min(50,Number(process.env.DB_POOL_MAX)||10)) });
export const db = drizzle(pool, { schema });

export * from "./schema";
export type { PoolClient } from 'pg';
